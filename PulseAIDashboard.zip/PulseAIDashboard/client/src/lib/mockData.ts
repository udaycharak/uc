import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Briefcase, 
  DollarSign, 
  Percent, 
  Droplet, 
  BarChart3,
  Globe
} from "lucide-react";

export interface Indicator {
  id: string;
  name: string;
  value: number;
  unit: string;
  change: number; // Percentage change or absolute change
  changeType: 'positive' | 'negative' | 'neutral'; // Is the change 'good' or 'bad' economically?
  icon: any;
  description: string;
  history: { date: string; value: number }[];
}

export interface RiskScore {
  score: number;
  level: 'Low' | 'Moderate' | 'High' | 'Critical';
  trend: 'improving' | 'worsening' | 'stable';
  details: {
    inflationImpact: number;
    yieldCurveImpact: number;
    unemploymentImpact: number;
    volatilityImpact: number;
  };
}

export type CountryCode = 'US' | 'UK' | 'IN';

export const countries: { code: CountryCode; name: string; flag: string }[] = [
  { code: 'US', name: 'United States', flag: '🇺🇸' },
  { code: 'UK', name: 'United Kingdom', flag: '🇬🇧' },
  { code: 'IN', name: 'India', flag: '🇮🇳' },
];

// Mock History Generator
const generateHistory = (base: number, variance: number, count: number = 12) => {
  return Array.from({ length: count }).map((_, i) => ({
    date: `2024-${(i + 1).toString().padStart(2, '0')}`,
    value: base + (Math.random() * variance * 2 - variance)
  }));
};

const indicatorsUS: Record<string, Indicator> = {
  inflation: {
    id: 'inflation',
    name: 'Inflation (CPI)',
    value: 3.4,
    unit: '%',
    change: -0.1,
    changeType: 'positive',
    icon: Percent,
    description: 'Consumer Price Index YoY',
    history: generateHistory(3.4, 0.5)
  },
  unemployment: {
    id: 'unemployment',
    name: 'Unemployment',
    value: 4.1,
    unit: '%',
    change: 0.2,
    changeType: 'negative',
    icon: Briefcase,
    description: 'National Unemployment Rate',
    history: generateHistory(4.0, 0.3)
  },
  pmi: {
    id: 'pmi',
    name: 'Manufacturing PMI',
    value: 49.2,
    unit: 'pts',
    change: -0.5,
    changeType: 'negative',
    icon: Activity,
    description: 'Purchasing Managers Index',
    history: generateHistory(50, 2)
  },
  yield_curve: {
    id: 'yield_curve',
    name: 'Yield Curve (10Y-2Y)',
    value: -0.35,
    unit: 'bps',
    change: 0.05,
    changeType: 'positive',
    icon: TrendingUp,
    description: 'Treasury Yield Spread',
    history: generateHistory(-0.4, 0.1)
  },
  vix: {
    id: 'vix',
    name: 'VIX Volatility',
    value: 13.8,
    unit: 'idx',
    change: -1.2,
    changeType: 'positive',
    icon: BarChart3,
    description: 'CBOE Volatility Index',
    history: generateHistory(15, 3)
  },
  oil: {
    id: 'oil',
    name: 'Brent Crude',
    value: 82.45,
    unit: '$',
    change: 1.5,
    changeType: 'negative',
    icon: Droplet,
    description: 'Crude Oil Price',
    history: generateHistory(80, 5)
  },
  fx: {
    id: 'fx',
    name: 'USD Index',
    value: 104.2,
    unit: 'idx',
    change: 0.1,
    changeType: 'neutral',
    icon: DollarSign,
    description: 'DXY Currency Index',
    history: generateHistory(104, 1)
  },
};

const indicatorsUK: Record<string, Indicator> = {
  inflation: {
    id: 'inflation',
    name: 'Inflation (CPI)',
    value: 4.0,
    unit: '%',
    change: 0.0,
    changeType: 'neutral',
    icon: Percent,
    description: 'UK CPI YoY',
    history: generateHistory(4.0, 0.6)
  },
  unemployment: {
    id: 'unemployment',
    name: 'Unemployment',
    value: 3.8,
    unit: '%',
    change: -0.1,
    changeType: 'positive',
    icon: Briefcase,
    description: 'ILO Unemployment Rate',
    history: generateHistory(3.9, 0.2)
  },
  pmi: {
    id: 'pmi',
    name: 'Services PMI',
    value: 53.8,
    unit: 'pts',
    change: 0.4,
    changeType: 'positive',
    icon: Activity,
    description: 'S&P Global/CIPS UK Services PMI',
    history: generateHistory(53, 1.5)
  },
  yield_curve: {
    id: 'yield_curve',
    name: 'Gilt Yield (10Y)',
    value: 4.10,
    unit: '%',
    change: 0.08,
    changeType: 'negative',
    icon: TrendingUp,
    description: '10-Year Gilt Yield',
    history: generateHistory(4.0, 0.2)
  },
  vix: {
    id: 'vix',
    name: 'FTSE 100 Volatility',
    value: 14.5,
    unit: 'idx',
    change: -0.5,
    changeType: 'positive',
    icon: BarChart3,
    description: 'Market Volatility',
    history: generateHistory(15, 2)
  },
  oil: {
    id: 'oil',
    name: 'Brent Crude',
    value: 82.45,
    unit: '$',
    change: 1.5,
    changeType: 'negative',
    icon: Droplet,
    description: 'Crude Oil Price',
    history: generateHistory(80, 5)
  },
  fx: {
    id: 'fx',
    name: 'GBP / USD',
    value: 1.26,
    unit: '$',
    change: -0.002,
    changeType: 'negative',
    icon: DollarSign,
    description: 'Exchange Rate',
    history: generateHistory(1.26, 0.03)
  },
};

const indicatorsIN: Record<string, Indicator> = {
  inflation: {
    id: 'inflation',
    name: 'Inflation (CPI)',
    value: 5.1,
    unit: '%',
    change: -0.2,
    changeType: 'positive',
    icon: Percent,
    description: 'Retail Inflation YoY',
    history: generateHistory(5.3, 0.4)
  },
  unemployment: {
    id: 'unemployment',
    name: 'Unemployment',
    value: 8.0,
    unit: '%',
    change: 0.5,
    changeType: 'negative',
    icon: Briefcase,
    description: 'CMIE Unemployment Rate',
    history: generateHistory(7.5, 1.0)
  },
  pmi: {
    id: 'pmi',
    name: 'Manufacturing PMI',
    value: 56.5,
    unit: 'pts',
    change: 0.5,
    changeType: 'positive',
    icon: Activity,
    description: 'HSBC India Manufacturing PMI',
    history: generateHistory(56, 1.5)
  },
  yield_curve: {
    id: 'yield_curve',
    name: 'Bond Yield (10Y)',
    value: 7.08,
    unit: '%',
    change: -0.02,
    changeType: 'positive',
    icon: TrendingUp,
    description: '10-Year G-Sec Yield',
    history: generateHistory(7.1, 0.1)
  },
  vix: {
    id: 'vix',
    name: 'India VIX',
    value: 15.2,
    unit: 'idx',
    change: 0.8,
    changeType: 'negative',
    icon: BarChart3,
    description: 'NIFTY Volatility Index',
    history: generateHistory(14, 2)
  },
  oil: {
    id: 'oil',
    name: 'Crude Basket',
    value: 81.20,
    unit: '$',
    change: 1.2,
    changeType: 'negative',
    icon: Droplet,
    description: 'Indian Crude Basket',
    history: generateHistory(79, 4)
  },
  fx: {
    id: 'fx',
    name: 'USD / INR',
    value: 83.10,
    unit: '₹',
    change: 0.05,
    changeType: 'negative',
    icon: DollarSign,
    description: 'Exchange Rate',
    history: generateHistory(83, 0.2)
  },
};

export const mockIndicatorsByCountry: Record<CountryCode, Record<string, Indicator>> = {
  US: indicatorsUS,
  UK: indicatorsUK,
  IN: indicatorsIN,
};

export const mockRiskScoreByCountry: Record<CountryCode, RiskScore> = {
  US: {
    score: 55,
    level: 'Moderate',
    trend: 'stable',
    details: {
      inflationImpact: 25,
      yieldCurveImpact: 20,
      unemploymentImpact: 20,
      volatilityImpact: 10,
    }
  },
  UK: {
    score: 62,
    level: 'High',
    trend: 'worsening',
    details: {
      inflationImpact: 35,
      yieldCurveImpact: 15,
      unemploymentImpact: 15,
      volatilityImpact: 15,
    }
  },
  IN: {
    score: 42,
    level: 'Moderate',
    trend: 'improving',
    details: {
      inflationImpact: 30,
      yieldCurveImpact: 10,
      unemploymentImpact: 25,
      volatilityImpact: 15,
    }
  },
};

export const mockAISummaryByCountry: Record<CountryCode, string> = {
  US: `
**US Macro Outlook:**
The US economy shows resilience with **inflation at 3.4%**, trending downwards. However, the **inverted yield curve (-0.35 bps)** persists as a long-term recession signal.

**Key Risks:**
Stickier-than-expected services inflation and geopolitical tensions impacting oil prices (**$82.45**) remain primary concerns.

**Conclusion:**
A **Moderate Risk (55)** environment prevails. The Fed is likely to hold rates steady until inflation convincingly approaches the 2% target.
`,
  UK: `
**UK Macro Outlook:**
The UK faces stiffer headwinds with **inflation at 4.0%**, higher than peers. Growth remains sluggish, though the **Services PMI (53.8)** offers a bright spot.

**Key Risks:**
Stagflation risk is elevated compared to the US. **Unemployment at 3.8%** is low but showing signs of ticking up.

**Conclusion:**
**High Risk (62)** reflects the delicate balancing act for the Bank of England between taming inflation and avoiding a deep recession.
`,
  IN: `
**India Macro Outlook:**
India demonstrates strong momentum with **Manufacturing PMI at 56.5**, signaling robust expansion. **Inflation at 5.1%** remains within the RBI's tolerance band but needs monitoring.

**Key Risks:**
Volatile food prices and global oil shocks (**Crude Basket $81.20**) are the main external vulnerabilities.

**Conclusion:**
**Moderate-Low Risk (42)** driven by strong domestic demand and capital expenditure. The outlook remains positive relative to developed markets.
`
};
