import { mockIndicatorsByCountry, mockRiskScoreByCountry, mockAISummaryByCountry, countries, CountryCode } from "@/lib/mockData";
import { IndicatorCard } from "@/components/IndicatorCard";
import { RiskScoreWidget } from "@/components/RiskScoreWidget";
import { AISummary } from "@/components/AISummary";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, Settings, Bell, Search, ChevronDown } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Dashboard() {
  const [selectedCountry, setSelectedCountry] = useState<CountryCode>('US');

  const currentIndicators = mockIndicatorsByCountry[selectedCountry];
  const currentRiskScore = mockRiskScoreByCountry[selectedCountry];
  const currentSummary = mockAISummaryByCountry[selectedCountry];
  const currentCountryInfo = countries.find(c => c.code === selectedCountry) || countries[0];

  return (
    <div className="min-h-screen bg-background text-foreground p-6 space-y-8 font-sans selection:bg-primary/20">
      {/* Header / Top Bar */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-border/40">
        <div className="flex items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
              MacroPulse
            </h1>
            <p className="text-muted-foreground mt-1">
              Global Macro Environment Dashboard
            </p>
          </div>
          
          <div className="h-8 w-px bg-border mx-2 hidden md:block" />

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="bg-card/30 border-white/10 hover:bg-card/50 min-w-[140px] justify-between">
                <span className="flex items-center gap-2">
                  <span className="text-lg">{currentCountryInfo.flag}</span>
                  {currentCountryInfo.name}
                </span>
                <ChevronDown className="h-4 w-4 opacity-50" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-[160px] bg-card border-white/10">
              {countries.map((country) => (
                <DropdownMenuItem 
                  key={country.code}
                  onClick={() => setSelectedCountry(country.code)}
                  className="cursor-pointer gap-2"
                >
                  <span className="text-lg">{country.flag}</span>
                  {country.name}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="relative hidden md:block w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input 
              type="search" 
              placeholder="Search indicators..." 
              className="pl-9 bg-card/30 border-white/5 focus:border-primary/50 transition-colors" 
            />
          </div>
          <Button variant="outline" size="icon" className="border-white/10 bg-card/30 hover:bg-card/50 text-muted-foreground">
            <Bell className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="border-white/10 bg-card/30 hover:bg-card/50 text-muted-foreground">
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Main Grid */}
      <main className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Indicators (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Key Stats Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            <IndicatorCard indicator={currentIndicators.inflation} />
            <IndicatorCard indicator={currentIndicators.unemployment} />
            <IndicatorCard indicator={currentIndicators.yield_curve} />
            <IndicatorCard indicator={currentIndicators.pmi} />
            <IndicatorCard indicator={currentIndicators.vix} />
            <IndicatorCard indicator={currentIndicators.oil} />
          </div>

          {/* Secondary / Charts Row (Placeholder for deeper dive) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <IndicatorCard indicator={currentIndicators.fx} />
             {/* Placeholder for another widget if needed */}
          </div>

        </div>

        {/* Right Column: Intelligence & Risk (4 cols) */}
        <div className="lg:col-span-4 space-y-6 flex flex-col h-full">
          <div className="flex-none">
            <RiskScoreWidget risk={currentRiskScore} />
          </div>
          <div className="flex-grow">
            <AISummary summary={currentSummary} />
          </div>
        </div>
      </main>
      
      <footer className="text-center text-xs text-muted-foreground pt-8 pb-4 border-t border-border/40 mt-8">
        <p>Data delayed by 15 minutes. Market data provided by Yahoo Finance API (Mock).</p>
        <p className="mt-1">MacroPulse © 2024 Design Engineer Prototype</p>
      </footer>
    </div>
  );
}
