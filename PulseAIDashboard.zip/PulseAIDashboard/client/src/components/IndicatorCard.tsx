import { motion } from "framer-motion";
import { Indicator } from "@/lib/mockData";
import { ArrowUp, ArrowDown, Minus } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface IndicatorCardProps {
  indicator: Indicator;
}

export function IndicatorCard({ indicator }: IndicatorCardProps) {
  const isPositive = indicator.changeType === 'positive';
  const isNegative = indicator.changeType === 'negative';
  const ChangeIcon = indicator.change > 0 ? ArrowUp : indicator.change < 0 ? ArrowDown : Minus;
  
  // Determine color based on "goodness" not just direction
  const trendColor = isPositive ? "text-emerald-500" : isNegative ? "text-rose-500" : "text-amber-500";
  const chartColor = isPositive ? "#10b981" : isNegative ? "#f43f5e" : "#f59e0b";

  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="bg-card/50 border-white/5 backdrop-blur-sm overflow-hidden hover:border-white/10 transition-colors">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            {indicator.name}
          </CardTitle>
          <indicator.icon className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="flex items-baseline justify-between">
            <div className="text-2xl font-bold font-mono tracking-tight">
              {indicator.value}
              <span className="text-sm font-normal text-muted-foreground ml-1">{indicator.unit}</span>
            </div>
            <div className={`flex items-center text-xs font-medium ${trendColor}`}>
              <ChangeIcon className="h-3 w-3 mr-1" />
              {Math.abs(indicator.change)}%
            </div>
          </div>
          
          <div className="h-[60px] mt-4 -mx-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={indicator.history}>
                <defs>
                  <linearGradient id={`gradient-${indicator.id}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={chartColor} stopOpacity={0.3}/>
                    <stop offset="95%" stopColor={chartColor} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Tooltip 
                  contentStyle={{ background: '#1e293b', border: 'none', borderRadius: '4px', color: '#fff' }}
                  itemStyle={{ color: '#fff' }}
                  cursor={{ stroke: 'rgba(255,255,255,0.1)' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke={chartColor} 
                  fillOpacity={1} 
                  fill={`url(#gradient-${indicator.id})`} 
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          
          <p className="text-xs text-muted-foreground mt-2 truncate">
            {indicator.description}
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
}
