import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface AISummaryProps {
  summary: string;
}

export function AISummary({ summary }: AISummaryProps) {
  const [isLoading, setIsLoading] = useState(false);
  
  // We don't use the state for display text in this mock, just the prop
  const displayText = summary;

  const handleRefresh = () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
    }, 1500);
  };

  return (
    <Card className="h-full bg-gradient-to-br from-card/50 to-primary/5 border-white/5 backdrop-blur-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2 text-lg font-medium text-foreground/90">
          <Sparkles className="h-4 w-4 text-primary" />
          AI Market Analysis
        </CardTitle>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-8 text-xs text-muted-foreground hover:text-primary"
          onClick={handleRefresh}
          disabled={isLoading}
        >
          {isLoading ? "Analyzing..." : "Refresh Analysis"}
        </Button>
      </CardHeader>
      <CardContent>
        <div className={`prose prose-invert prose-sm max-w-none text-muted-foreground leading-relaxed ${isLoading ? 'animate-pulse opacity-50' : ''}`}>
           {displayText.split('\n').map((line, i) => {
             if (!line.trim()) return <br key={i} />;
             return (
               <p key={i} className="mb-2 last:mb-0">
                 {line.split('**').map((part, j) => 
                   j % 2 === 1 ? <strong key={j} className="text-foreground font-semibold">{part}</strong> : part
                 )}
               </p>
             );
           })}
        </div>
      </CardContent>
    </Card>
  );
}
