import { RiskScore } from "@/lib/mockData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";

interface RiskScoreWidgetProps {
  risk: RiskScore;
}

export function RiskScoreWidget({ risk }: RiskScoreWidgetProps) {
  // Calculate color based on score
  // 0-30: Low (Green), 31-60: Moderate (Amber), 61+: High (Red)
  const getColor = (score: number) => {
    if (score < 30) return "text-emerald-500";
    if (score < 60) return "text-amber-500";
    return "text-rose-500";
  };

  const getBgColor = (score: number) => {
    if (score < 30) return "bg-emerald-500";
    if (score < 60) return "bg-amber-500";
    return "bg-rose-500";
  };

  const circumference = 2 * Math.PI * 40; // Radius 40
  const strokeDashoffset = circumference - (risk.score / 100) * circumference;

  return (
    <Card className="h-full bg-card/50 border-white/5 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-lg font-medium text-foreground/90">Macro Risk Score</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center justify-center pt-0">
        <div className="relative w-48 h-48 flex items-center justify-center">
          {/* SVG Gauge */}
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="96"
              cy="96"
              r="40"
              stroke="currentColor"
              strokeWidth="8"
              fill="transparent"
              className="text-muted/20"
            />
            <motion.circle
              initial={{ strokeDashoffset: circumference }}
              animate={{ strokeDashoffset }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              cx="96"
              cy="96"
              r="40"
              stroke="currentColor"
              strokeWidth="8"
              fill="transparent"
              strokeDasharray={circumference}
              strokeLinecap="round"
              className={getColor(risk.score)}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className={`text-4xl font-bold font-mono ${getColor(risk.score)}`}>
              {risk.score}
            </span>
            <span className="text-sm text-muted-foreground uppercase tracking-wider font-medium mt-1">
              {risk.level}
            </span>
          </div>
        </div>

        <div className="w-full grid grid-cols-2 gap-4 mt-4">
          <div className="space-y-1">
            <div className="text-xs text-muted-foreground">Trend</div>
            <div className="text-sm font-medium capitalize text-foreground">{risk.trend}</div>
          </div>
          <div className="space-y-1">
            <div className="text-xs text-muted-foreground">Last Updated</div>
            <div className="text-sm font-medium text-foreground">Just now</div>
          </div>
        </div>

        <div className="w-full mt-6 space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">Inflation Impact</span>
            <span className="text-foreground">{risk.details.inflationImpact}%</span>
          </div>
          <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-foreground/20 rounded-full" style={{ width: `${risk.details.inflationImpact}%` }} />
          </div>
          
          <div className="flex justify-between text-xs pt-2">
            <span className="text-muted-foreground">Yield Curve Impact</span>
            <span className="text-foreground">{risk.details.yieldCurveImpact}%</span>
          </div>
          <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-foreground/20 rounded-full" style={{ width: `${risk.details.yieldCurveImpact}%` }} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
